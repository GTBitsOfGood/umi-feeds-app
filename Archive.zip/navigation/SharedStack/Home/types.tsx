export type HomeScreenParamList = {
  Home: undefined;
  NewDonorName: undefined;
  NewDonorNumber: undefined;
  NewDonorLocation: undefined;
  DonationView: undefined;
  MyDishes: undefined;
  AllDonations: undefined;
};
