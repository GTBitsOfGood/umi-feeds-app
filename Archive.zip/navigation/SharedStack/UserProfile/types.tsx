export type UserProfileScreenParamList = {
  UserProfileScreen: undefined;
  EditUserProfileScreen: undefined;
}
