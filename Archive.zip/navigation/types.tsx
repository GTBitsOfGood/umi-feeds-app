export type RootStackParamList = {
  Login: undefined;
  Root: undefined;
  NotFound: undefined;
};
