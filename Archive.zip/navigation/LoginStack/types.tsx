export type LoginStackParamList = {
  Login: undefined;
  OnboardingForm: undefined;
};
