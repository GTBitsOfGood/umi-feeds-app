export type BottomTabParamList = {
  Home: undefined;
  Donate: undefined;
  Map: undefined;
  Donations: undefined;
  Me: undefined;
};
