export type MapScreenParamList = {
  MapScreen: undefined;
  DonationDetails: undefined;
  EditDonation: undefined;
};
