export type DonationScreenParamList = {
  DonationScreen: undefined;
};
