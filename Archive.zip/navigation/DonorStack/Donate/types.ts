export type DonateTabParamList = {
  DonateHomeScreen: undefined,
  NewDishForm: undefined,
  DishProfile: undefined,
  DishSearch: undefined,
  DonateListScreen: undefined,
  AddressScreen: undefined,
  SchedulePickupScreen: undefined,
  ReviewScreen: undefined,
};
